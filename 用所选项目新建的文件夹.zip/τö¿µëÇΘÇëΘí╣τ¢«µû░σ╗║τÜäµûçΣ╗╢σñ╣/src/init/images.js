import leftimg from '../images/left.png';
import Conversion from '../images/Conversion.png';
import topimg from '../images/top.png';
import searchimg from '../images/search.png';
import login from '../images/login.png';
import out from '../images/out.png';
var images = {
    leftimg: leftimg,
    Conversion:Conversion,
    topimg: topimg,
    searchimg:searchimg,
    login:login,
    out:out
}
export default images;