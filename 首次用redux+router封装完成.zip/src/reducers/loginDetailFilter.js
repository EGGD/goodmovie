const loginDetailFilter = (state = {
    detail: {}
}, action) => {
    // debugger
    switch (action.type) {
        case 'LOGIN_DETAIL':
            return { ...state, detail: action.detail.msg, Password: "" };
        case 'LOGIN_CHANGE':
            if (action.login.name === 'Name') {
                return { ...state, Name: action.login.value }
            } else if (action.login.name === 'Password') {
                return { ...state, Password: action.login.value }
            }
        case 'OUT_LOGIN':
            return { ...state, detail: {}, Name: "" }
        default:
            return state;
    }
}
export default loginDetailFilter;