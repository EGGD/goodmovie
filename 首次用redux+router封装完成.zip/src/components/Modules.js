//右侧悬浮栏内容
import React from 'react';
import { connect } from 'react-redux';
import Seen from './Seen';
import DetailMovie from './DetailMovie';
import Login from './Login';

const Modules = ({ active, onClick, onSetClick, onLoginClick, onLoginChange }) => {
    
    let modulesData = active.showModulesFilter;
    let headerData = active.headerFilter;
    let loginDetailFilter = active.loginDetailFilter;
    // console.log(active);
    let Content2 = headerData.map((e, index) => {
        if (e.showDataFlg && e.name === 'NotSeen_Movies')
            return <Seen onClick={onClick} data={modulesData.notSeenData} key={index} />;
        else if (e.showDataFlg && e.name === 'HaveSeen_Movies')
            return <Seen onClick={onClick} data={modulesData.haveSeenData} key={index} />;
        else if (e.showDataFlg && e.name === 'Detail_Movies')
            return <DetailMovie onClick={onSetClick} data={modulesData.detail} key={index} />
        else if (e.showDataFlg && e.name === 'Login')
            return <Login onLoginChange={onLoginChange} onLoginClick={onLoginClick} data={active} key={index} />;
        else if (e.showDataFlg && e.name === 'Add_Movies')
            return e.name;
    });


    return (
        <ul className="content">
            {Content2}
        </ul>
    )
}
export default Modules;
