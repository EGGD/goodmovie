//导航栏内容
import '../css/Init.css'
import '../css/Computer.css';
import React from 'react';
import Seen from './Seen';
import DetailMovie from './DetailMovie';
import Login from './Login';
import {
    Router,
    Route,
    Link,
} from 'react-router-dom';
import history from '../init/history'

const Header = ({ active, data, onClick, onTotalClick, onSetClick, onLoginClick, onLoginChange }) => {
    let modulesData = data.showModulesFilter;
    let headerData = data.headerFilter;
    let loginDetailFilter = data.loginDetailFilter;
    let headerlist = active.map((value, key) => {
        return (
            <Link to={`/${value.name}`} onClick={(e) => {
                e.defaultPrevented;
                onTotalClick(value)
            }} key={key}>{value.name}</Link>
        )
    })
    return (
        <Router history={history}>
            <div>
                <header>
                    <h1>GoodMovies</h1>
                    <nav>
                        <div>
                            <ul>
                                {headerlist}
                            </ul>
                        </div>
                    </nav>
                </header>
                <ul className="content">
                    <Route exact path="/NotSeen_Movies" component={() => <Seen onClick={onClick} data={modulesData.notSeenData} />} />
                    <Route exact path="/HaveSeen_Movies" component={() => <Seen onClick={onClick} data={modulesData.haveSeenData} />} />
                    <Route exact path="/Detail_Movies" component={() => <DetailMovie onClick={onSetClick} data={modulesData.detail}  />} />
                    <Route exact path="/Login" component={() => <Login onLoginChange={onLoginChange} onLoginClick={onLoginClick} data={active} />} />
                </ul>
            </div>
        </Router>
    )
}
export default Header;
