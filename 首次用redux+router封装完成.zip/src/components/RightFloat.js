//右侧悬浮栏内容
import React from 'react';
import img from '../init/images'
const RightFloat = ({ active, onClick, onSetClick }) => {    
    let onDetailFlg = active.headerFilter.filter((value) => value.showDataFlg === true)[0].name;
    let loginDetail = active.loginDetailFilter;
    let showModulesFilter = active.showModulesFilter;
    let showLogin = JSON.stringify(loginDetail.detail) === '{}' ? true : false;
    return (
        <div className="divAbsolute">
            <img alt="top" src={img.topimg} />
            <img alt="login"
                src={JSON.stringify(loginDetail.detail) === '{}' ? img.login : img.out}
                onClick={e => {
                    e.defaultPrevented;
                    onClick(showLogin)
                }} />
            <img alt="Conversion" src={img.Conversion}
                className={onDetailFlg === 'Detail_Movies' ? '' : 'displayNone'}
                onClick={e => {
                    e.defaultPrevented;
                    onSetClick(showModulesFilter)
                }} />
            {active.showModulesFilter.total}
        </div>
    )
}
export default RightFloat;

