import React from 'react';
import Header from '../components/Header';
import HeaderList from './HeaderList';
import RightFloatList from './RightFloatList';


const App = () => (
  <div>
    <HeaderList />
    <RightFloatList/>
  </div>
)
export default App;