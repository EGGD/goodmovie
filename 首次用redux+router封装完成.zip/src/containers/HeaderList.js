import { connect } from 'react-redux';
import Header from '../components/Header';
import { getModulesTotal, moviesDetail,changeFilters, changeHeaderFilters, Login, loginChange } from '../actions';
import history from '../init/history'


const getHeaderNavFlg = (value) => {
  return value.filter((value) => value.showNavFlg)
}

const mapStateToProps = (state) => ({
  active: getHeaderNavFlg(state.headerFilter),
  data: state
})


const mapDispatchToProps = (dispatch) => ({
  onClick: (value) => {
    //传递详情页内容
    dispatch(moviesDetail(value));
    //导航切换
    dispatch(changeFilters('Detail_Movies'))
    //改变header分栏显示
    dispatch(changeHeaderFilters('Detail_Movies'));
    dispatch(getModulesTotal('Detail_Movies'));
    history.push('/Detail_Movies');
  },
  onTotalClick: (value) => {
    dispatch(getModulesTotal(value.name));
  },
  onLoginClick: (value, flg) => {
    dispatch(Login(value))
  },
  onLoginChange: (value, name) => {
    dispatch(loginChange({ value, name }))
  }
})

const HeaderList = connect(
  mapStateToProps,
  mapDispatchToProps
)(Header)

export default HeaderList;
